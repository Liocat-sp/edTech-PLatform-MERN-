export const INPUT_CHANGE = "INPUT_CHANGE";
export const USER_LOGIN = "USER_LOGIN";