export { default } from "./Template";
